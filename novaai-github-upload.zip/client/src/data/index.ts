export * from './ethics-course';
export * from './law-course';