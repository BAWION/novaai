// Base64 изображения скриншотов
export const screenshotImages = {
  coursesCatalog: 'data:image/png;base64,' + 'iVBORw0KGgoAAAANSUhEUgAABXA...', // здесь будет ваша строка base64
  labhub: 'data:image/png;base64,' + 'iVBORw0KGgoAAAANSUhEUgAABXA...', // здесь будет ваша строка base64
  businessAi: 'data:image/png;base64,' + 'iVBORw0KGgoAAAANSUhEUgAABXA...', // здесь будет ваша строка base64
  profile: 'data:image/png;base64,' + 'iVBORw0KGgoAAAANSUhEUgAABXA...' // здесь будет ваша строка base64
};