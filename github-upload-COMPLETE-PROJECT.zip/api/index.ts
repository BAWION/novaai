import { createServer } from '../server/index.js';

export default createServer;