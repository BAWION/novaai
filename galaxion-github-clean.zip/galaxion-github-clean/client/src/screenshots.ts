// Base64 URLs для изображений (без зависимости от файловой системы)
export const screenshots = {
  coursesCatalog: 'data:image/png;base64,iVBORw0KGgoAAAANSUhE',
  labhub: 'data:image/png;base64,iVBORw0KGgoAAAANSUhE',
  businessAi: 'data:image/png;base64,iVBORw0KGgoAAAANSUhE',
  profile: 'data:image/png;base64,iVBORw0KGgoAAAANSUhE'
};