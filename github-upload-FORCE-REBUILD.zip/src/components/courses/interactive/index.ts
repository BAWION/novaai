export { default as MultipleChoiceQuiz } from './multiple-choice-quiz';
export { default as PracticalAssignment } from './practical-assignment';
export type { QuizOption } from './multiple-choice-quiz';
export type { PracticalAssignmentProps } from './practical-assignment';